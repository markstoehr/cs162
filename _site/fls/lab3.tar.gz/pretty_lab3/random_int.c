/** @random_int.c
 *  @brief Prototypes for generating pseudo-random integers 
 *         within a half-open interval
 *         of integers with lower bound equal to 0
 *         and random generation of integers representing a set
 *         
 *
 *
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>. 
 *  Copyright (C) 2015
 *
 *  @author Mark Stoehr ()
 *  @date 2015-02-02
 *  @bug No known bugs.
 */

#include "random_int.h"

#include <stdlib.h>

int random_int(int upper_bound) {
  int product_upper_bound = (RAND_MAX/upper_bound) * upper_bound;
  int out;    
  do {
    out = rand();
  } while (out >= product_upper_bound);
  return out % upper_bound;
}

int random_set_int(int upper_bound) {
  return random_int( 1 << upper_bound );

}
