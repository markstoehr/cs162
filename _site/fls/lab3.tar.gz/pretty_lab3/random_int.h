/** @random_int.h
 *  @brief Prototypes for generating pseudo-random integers 
 *         within a half-open interval
 *         of integers with lower bound equal to 0
 *         and random generation of integers representing a set
 *         
 *
 *
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>. 
 *  Copyright (C) 2015
 *
 *  @author Mark Stoehr ()
 *  @date 2015-02-02
 *  @bug No known bugs.
 */

/* @brief  produce a pseudo random integer below an upperbound
 *         and greater than zero
 *
 * @param int upper_bound
 *        pseudo-random integer produced is less than the upper bound
 *        total set of random integer is of size upperbound
 *
 */
int random_int(int);

/* @brief  produce a pseudo random integer below  2^upperbound
 *         bits represent items included
 *
 * @param int upper_bound
 *        the number of potential non-zero bits of produced 
 *        pseudo-random integer is equal to upper_bound
 *        so the bits can be seen as representing set inclusion
 */
int random_set_int(int);

