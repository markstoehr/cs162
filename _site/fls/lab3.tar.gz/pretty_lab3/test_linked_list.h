/** @test_linked_list.h
 *  @brief Function prototypes to test linked_list on simple examples
 *
 *  This contains the prototypes for the linked
 *  list implementation test. This is an informal test
 *  that is meant to just demonstrate some functionality of the list
 *  
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>. 
 *  Copyright (C) 2015
 *
 *  @author Mark Stoehr ()
 *  @date 2015-02-02
 *  @bug No known bugs.
 */

#ifndef _CODE_PRETTY_LAB3_TEST_LINKED_LIST_H_
#define _CODE_PRETTY_LAB3_TEST_LINKED_LIST_H_

#include <stdbool.h>

#include "linked_list.h"

/* @brief Make sure that you can create a list and it is seen as empty
 *
 *  Here we create a list, put some values into it, and then remove those values
 *  and then destroy the list.  This is just to make sure that the code works.
 *  We use list equals to get the desired effect.
 *
 *
 *
 *
 */
bool test_List_create();


/* @brief Make sure that you can create a list that contains values
 *
 *  Here we create a list, put some values into it, and then remove those values
 *  and then destroy the list.  This is just to make sure that the code works.
 *  We use list equals to get the desired effect.
 *
 *
 *
 *
 */
bool test_List_push();

/* @brief Make sure that reinsertion works
 *
 *  Here we create a list, put some values into it, and then we test out
 *  reinsertion and make sure that has the desired effect on the list.
 *  We create two lists by hand one that has the entries
 *  1 2 3 4
 *  then 
 *  2 4
 *  and check that insertion and reinsertion with an API-allocated
 *  list still works
 */
bool test_List_reinsert();

/* @brief Explore whether the same list produced twice is seen as equal
 *
 *  Here we create a list, put some values into it, and then we test out
 *  reinsertion and make sure that has the desired effect on the list.
 *  
 *  
 *
 *
 *
 *
 */
bool test_List_equal();

#endif // _CODE_PRETTY_LAB3_TEST_LINKED_LIST_H_
