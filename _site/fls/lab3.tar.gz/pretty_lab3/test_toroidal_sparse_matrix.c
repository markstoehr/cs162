/** @test_toroidal_sparse_matrix.c
 *  @brief Tests for functions in toroidal_sparse_matrix.h
 *         Which demonstrates functionality with 
 *         sparse matrices implement Knuth's doubly linked circularly linked lists
 *         representation
 *
 *
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>. 
 *  Copyright (C) 2015
 *
 *  @author Mark Stoehr ()
 *  @date 2015-02-02
 *  @bug No known bugs.
 */

#include "test_toroidal_sparse_matrix.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "toroidal_sparse_matrix.h"

void Print_simple_example_matrix() {
  printf("Allocating simple matrix\n");
  Matrix *matrix = Simple_Matrix_example();
  printf("now printing the matrix\n");
  Print_full_matrix(matrix);
  return;
}

int main() {
  srand(time(NULL));
  printf("Beginning tests by printing out a matrix:\n");
  Print_simple_example_matrix();
  
  printf("\n");
  Matrix *matrix = Matrix_create_random(15,20);
  Print_full_matrix(matrix);

  return 0;
}
