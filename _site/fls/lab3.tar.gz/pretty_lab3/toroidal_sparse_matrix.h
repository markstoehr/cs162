/** @toroidal_sparse_matrix.h
 *  @brief Function prototypes for a toroidal sparse matrix using 
 *         doubly linked circularly linked lists
 *
 *  This contains the prototypes for the sparse matrix over a torus
 *  represented using doubly linked circularly linked lists.
 *  We have implemented efficient algorithms for insertion
 *  and deletion which is special to the data structure.  Some of
 *  the algorithms are not optimally efficient, however,
 *  since as an intermediate data structure we use linked lists
 *  rather than priority queues or sorting 
 *  when iterating over elements (see matrix_entry_list.h). This
 *  is for clarity purposes in the program.
 *
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>. 
 *  Copyright (C) 2015
 *
 *  @author Mark Stoehr ()
 *  @date 2015-02-02
 *  @bug No known bugs.
 */

#ifndef _CODE_PRETTY_LAB3_TOROIDAL_SPARSE_MATRIX_H_
#define _CODE_PRETTY_LAB3_TOROIDAL_SPARSE_MATRIX_H_

/* @brief struct declaration for DLCL toroidal sparse matrix
 *
 *        The matrix data structure is a hierarchy of structs
 *        using struct pointers. There are two layers of
 *        doubly linked circularly linked lists involved in 
 *        constructing the matrix representation
 *        the first is a DLCL of column entries,
 *        the second is are DLCLs of matrix entries (one for each
 *        column).  There is also another structure where the rows
 *        are "headless" and "handless" DLCL lists so they just
 *        have the link structure.  
 *        The DLCL list of columns has a handle referred to as
 *        by the `matrix` field of each column node, and it is
 *        a `struct Matrix`.  Each column node is of type
 *        `struct MatrixColumn` and they have an `int index` field
 *        as well as a `struct MatrixEntry *head` that points
 *        to the head of the matrix column DLCL list, they also
 *        have a `root` field that points to the head of the
 *        column list.  The head of the column list is also
 *        called `root` by the `struct Matrix`.
 *
 *
 *  The invariants are simlar to what is found in linked_list.h
 *   in @ref IntListInvariants
 *
 *
 *  Entry invariants:
 *  In the following `node` is a `struct MatrixNode` object
 *
 *  @invariant `node->value >= 0`
 *
 *  @invariant `node->column == NULL` or 
 *              `node->column` points to a live
 *             `struct MatrixColumn` object which
 *             `node` belongs to
 *
 *  @invariant If `node->column` points to a live 
 *             `struct MatrixColumn` object and
 *             `(node->column)->head != node` (so `node`
 *              is not the head) then `node->value > 0`.
 *
 *
 *  @invariant If `node` belongs to `column` then
 *             `node->up` and `node->down` both point to live
 *             `struct MatrixNode` objects which belong to
 *             `column`.
 *
 *  @invariant  `node == (node->up)->down` and 
 *              `node == (node->down)->up`
 *
 *  @invariant  `node == (node->left)->right` and 
 *              `node == (node->right)->left`
 *
 *
 *  @invariant  If `node->column` is a live `struct MatrixColumn`
 *              object then for any live
 *              `struct MatrixNode` `x` belonging to
 *              `node->column` the following holds:
 *               there exists an integer `n` such that
 *               `0 <= n <= (node->column)->count`,
 *               `x` is the `n` down successor of
 *               `node` in `node->column`, and
 *               `x` is the `(node->column)->count - n+1`
 *                up successor of `node`.
 *
 *             The `n` down successor is defined inductively
 *             The node itself `node` is the `0` down succesor of
 *             `node`. If `x` is the `n` down successor of `node`
 *             then `x->down` is the `n+1` down successor of
 *             node. We give a similar inductive definition of
 *             `up` successor where we use the `up` field rather than
 *             the `down` field.  The same invariant holds for
 *             `left` and `right` successors as well.
 *
 *
 *  @invariant If `x` is a left/right successor of `node` then
 *             `x->value == node->value`.
 *
 *             This invariant captures the notion that the values  
 *             stored in `struct MatrixNode` is the row index
 *             for the entry.
 *
 *  
 *  @invariant If `x` is the `n > 0` down successor of `node`
 *             and for all `k` such that `0 < k <= n`
 *             the `k` down successor of `node` is not
 *             pointed to by `(node->column)->head` then
 *             `x->value > node->value`.
 *
 *             This invariant captures the notion that a matrix
 *             column should be sorted.  We have a similar
 *             for `up` successors. In this invariant
 *             for the hypothesis condition to be validated
 *             `x` is not `(node->column)->head` but
 *             `node` could be `(node->column)->head`.
 *
 *
 *  @invariant If `x` is the `n` up successor of `node`
 *             and for all `k` such that `0 <= k < n`
 *             the `k` up successor of `node` is not
 *             pointed to by `(node->column)->head` then
 *             `x->value < node->value`.
 *
 *             Note here that `x` could be `(node->column)->head`
 *             but that `node` is not the head in order to satisfy
 *             the hypothesis conditions of the invariant.
 *
 *  @invariant If `node` belongs to `column` then either
 *             `(node->column)->matrix` is NULL or
 *             `node` and `column` belong to a `struct Matrix`
 *             object pointed to by `(node->column)->matrix`.
 *
 *  @invariant If `node` belongs to a `struct Matrix` object
 *             `matrix` then `node->column`
 *             points to a live `struct MatrixColumn` object
 *             which belongs to `matrix`
 *
 *  @invariant If `(node->column)->matrix` pionts to a 
 *             live `struct Matrix` then `node->left`
 *             and `node->right` point to live
 *             `struct MatrixNode` objects
 *        
 *
 *  In the following `column` is a live `struct MatrixColumn`
 *  object
 *
 *
 *  @invariant Any `down` successor `node` of `column->head`
 *             belongs to `column` and we have
 *             `node->column == column`
 *
 *
 *  @invariant `column->head` points to a live
 *             `struct MatrixNode` object such that
 *             `(column->head)->value == 0`
 *
 *  @invariant `column->matrix == NULL` or  
 *             `column->matrix` points to a live `struct Matrix`
 *              object which `column` belongs to.
 *
 *  @invariant `column->left` and `column->right` point
 *              to live `struct MatrixColumn` objects and if
 *             `column` belongs to a matrix these are the 
 *             respective non-empty columns left and right
 *             of `column`
 *
 *  @invariant `(column->left)->right == column`
 *             `(column->right)->left == column`
 *
 *  @invariant If `column->matrix` is a live `struct Matrix`
 *             then `(column->matrix)->headcolumn` is a left
 *             successor and right success of `column`
 *
 *             Here `column->left` is a left successor of `column`
 *             and if `c` is a left successor of `column` then
 *             `c->left` is a left successor of `column`. We have
 *             a similar definition for a right successor using the
 *             `right` field rather than the `left` field. The
 *             set of nodes inductively included in this definition
 *             exactly defines the set of
 *             `left` and `right` successors of a given column.
 *
 *  In the following `matrix` is a live `struct Matrix`
 *  object
 *
 *  @invariant `matrix->headcolumn` is a live `struct MatrixColumn`
 *             object with `name` field `'0'`.
 *
 *  @invariant Any live `struct MatrixColumn` `node` that is a
 *             left successor of `matrix->headcolumn` is such that
 *             `matrix == node->matrix`
 *
 *
 *  There are many other invariants and this is just a sampling
 *  of them. 
 *
 */

struct MatrixNode;
struct MatrixColumn;
struct Matrix;

typedef struct MatrixNode {
  int value;
  struct MatrixNode *up;
  struct MatrixNode *right;
  struct MatrixNode *down;
  struct MatrixNode *left;
  struct MatrixColumn *column;
  struct MatrixRow *row;
} MatrixNode;

typedef struct MatrixColumn {
  int index;
  int size;
  MatrixNode *head;
  struct MatrixColumn *left;
  struct MatrixColumn *right;
  struct Matrix *matrix;
} MatrixColumn;

typedef struct MatrixRow {
  int index;
  int size;
  MatrixNode *head;
  struct MatrixRow *up;
  struct MatrixRow *down;
  struct Matrix *matrix;
} MatrixRow;


typedef struct Matrix {
  int height;  /**< largest owned MatrixNode value */
  int width;   /**< largest column name */
  int nnz_rows; /**< number of non-zero rows */
  int nnz_columns; /**< number of non-zero columns */
  int nnz;  /**< number of non-zero elements */
  MatrixColumn *headcolumn;
  MatrixRow *headrow;
} Matrix;


/* @brief Create a column separate from a matrix
 *
 *  A column not belonging to any matrix is essentially a
 *  sparse vector.
 * 
 *  @param int index
 *         This is the name of the column and it will carry over to the matrix unlesss
 *         it is redundant in which case it will be replaced.
 * 
 *  @return MatrixColumn *column where `column == NULL` or
 *          `column` is a live `MatrixColumn` object
 *
 *  @post If `column != NULL` then `column->matrix == NULL`
 *  
 *  @post `column->head` points to a live `MatrixNode` object
 *
 *  @post If `column != NULL` then it should have no entries.
 *
 */
MatrixColumn *MatrixColumn_create(int);

/* @brief Create a column separate from a matrix
 *
 *  A column not belonging to any matrix is essentially a
 *  sparse vector.
 * 
 *  @param int index
 *         This is the name of the column and it will carry over to the matrix unlesss
 *         it is redundant in which case it will be replaced.
 * 
 *  @return MatrixColumn *column where `column == NULL` or
 *          `column` is a live `MatrixColumn` object
 *
 *  @post If `column != NULL` then `column->matrix == NULL`
 *  
 *  @post `column->head` points to a live `MatrixNode` object
 *
 *  @post If `column != NULL` then it should have no entries.
 *
 */
MatrixRow *MatrixRow_create(int);

/* @brief Deallocate a MatrixColumn and every MatrixNode that belongs
 *        to it.
 *
 *
 *
 * @param MatrixColumn *column
 *
 *
 * @post The memory locations pointed to by the entries belonging
 *       to `column` have been deallocated
 *
 * @post Any row for a prior member `node` of `column` has had `node`
 *       popped from the list (see `linked_list.h` for a discussion
 *       of "popping").
 *
 *
 *
 */
void MatrixColumn_destroy(MatrixColumn *);

/* @brief Deallocate a MatrixColumn and every MatrixNode that belongs
 *        to it.
 *
 *
 *
 * @param MatrixColumn *column
 *
 *
 * @post The memory locations pointed to by the entries belonging
 *       to `column` have been deallocated
 *
 * @post Any row for a prior member `node` of `column` has had `node`
 *       popped from the list (see `linked_list.h` for a discussion
 *       of "popping").
 *
 *
 *
 */
void MatrixRow_destroy(MatrixRow *);

/* @brief Create a new matrix node with a specified integer value
 *
 *
 *
 *
 * @param int value
 *        This will represent the row index
 *        of the non-zero entry corresponding
 *        this node
 *
 * @return MatrixNode *node
 *
 * @post  `node->column == NULL`
 * 
 * @post  `node->left == node->right == node->up == node->down == node`
 *         The node wraps around to itself because it belongs to no
 *          column or matrix
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
MatrixNode *MatrixNode_create(int);

/* @brief Deallocate and fix up references for a MatrixNode
 *
 *        We fix all links that we can
 *
 *
 * @param MatrixNode *node
 *        This is a pointer to the MatrixNode to be destroyed
 *        
 *
 * @post  freed memory for `node`
 * 
 * @post  `node->left`, `node->right`, `node->up`, `node->down`
 *         no longer point to the node
 *         This should reduce the risk of dereferencing a
 *         deallocated pointer
 *
 *
 */
void MatrixNode_destroy(MatrixNode *);

/* @brief Perform a linear search to find the node
 *        in a column that has the largest index
 *        no greater than the input value
 *
 * @param MatrixColumn *column
 * @param int value
 *        
 * @return MatrixNode *node
 *         This is a node in column
 *        
 *        
 *
 * @pre   `value >= 0`
 *
 * @post  `value == 0` implies that the returned node is
 *         `column->head
 *
 * @post  `node->column == column`
 *
 * @post  `node->value <= value`
 *
 * @post  `node->down > value` or `node->down == 0`
 *        This says that going further in the list will
 *        not get you a better indexed node.
 *
 */
MatrixNode *MatrixColumn_access(MatrixColumn *,int);



/* @brief Push a new entry into matrix column with a specified row index
 *
 *        We create a newly-allocated node with the specified index
 *        pushed into the column at the appropriate place
 *        we do nothing if that index already exists.
 *
 * @param MatrixColumn *column
 *        MatrixColumn to push a new MatrixNode into
 *
 * @param int index
 *        if index is not already in the column 
 *
 * @return MatrixNode *node
 *         The newly allocated node with the desire index
 *         or the already existant node with that
 *         index in the column.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
MatrixNode *MatrixColumn_push_value(MatrixColumn *,int);

/* @brief Create a new empty matrix
 *
 *
 */
Matrix *Matrix_create();

/* @brief Deallocate a matrix and its columns
 *
 *
 */
void Matrix_destroy(Matrix *matrix);

/* @brief Access a specified column of a matrix
 *
 *
 */
MatrixColumn* Matrix_access_column(Matrix *matrix,int);

/* @brief Access a specified row of a matrix
 *
 *
 */
MatrixRow* Matrix_access_row(Matrix *matrix,int);


/* @brief put a column into a matrix
 *
 * @param Matrix *matrix
 *        Matrix to insert the column into
 *
 * @param MatrixColumn *column
 *        MatrixColumn to insert into `matrix`
 *
 * @pre   column->matrix == NULL
 *        this means the column does not belong to any matrix
 *
 * @pre   column->index != c->index for any MatrixColumn `c`
 *        belonging to `matrix` to ensure no redundancy
 *
 * @post  for each MatrixNode `node` belonging to `column`
 *        if `matrix` owns a MatrixRow `row` such that
 *        if `row.index == node.value` then the `node` will
 *        be properly inserted into the row
 *
 * @post  for each MatrixNode `node` belonging to `column`
 *        if there is no MatrixRow `row` belonging to
 *        `matrix` such that `row.index == node.value`
 *        then a new row will be inserted into the matrix
 *        containing that node
 *
 *
 *
 *
 *
 *
 */
Matrix *Matrix_push_column(Matrix *, MatrixColumn *);


/* @brief Print the matrix row by row with all 1s and 0s
 *
 *
 */
void Print_full_matrix(Matrix *matrix);


/* @brief Create a simple example matrix to perform tests with
 *
 *
 */
Matrix *Simple_Matrix_example();

/* @brief Create a random matrix column
 *
 * @param int column_index
 *        Index for the column
 *
 * @param int max_rows
 *        Maximum number of rows
 */
MatrixColumn* MatrixColumn_create_random(int,int);

/* @brief Create a random matrix
 *
 * @param int max_rows
 *        Maximum number of rows
 *
 * @param int max_columns
 *        Maximum number of columns
 *
 */
Matrix *Matrix_create_random(int,int);


/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

#endif // _CODE_PRETTY_LAB3_TOROIDAL_SPARSE_MATRIX_H_
