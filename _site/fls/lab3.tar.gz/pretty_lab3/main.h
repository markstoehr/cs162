/** @main.h
 *  @brief Function prototypes for the console driver.
 *
 *  This contains the prototypes for the console
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 *
 *  @author Harry Q. Bovik (hqbovik)
 *  @author Fred Hacker (fhacker)
 *  @bug No known bugs.
 */

#ifndef _CODE_PRETTY_LAB3_MAIN_H_
#define _CODE_PRETTY_LAB3_MAIN_H_

/*
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 */

#endif // _CODE_PRETTY_LAB3_MAIN_H_
