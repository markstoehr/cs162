/** @linked_list.c
 *  @brief Implementation of linked list code
 *
 *  This contains the prototypes for the linked
 *  list implementations.  It contains ints and 
 *  we have implemented efficient algorithms for insertion
 *  and deletion which is special to the data structure.
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>. 
 *  Copyright (C) 2015
 *
 *  @author Mark Stoehr ()
 *  @date 2015-02-02
 *  @bug No known bugs.
 */


#include "linked_list.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>





IntList *List_create() {
  IntList *list = (IntList *)malloc(sizeof(IntList));
  if (!(list))
    return NULL;

  IntListNode *head = (IntListNode *)malloc(sizeof(IntListNode));
  if (!(head)) {
    free(list);
    return NULL;
  }

  head->value = -1;
  list->count = 0;
  list->head = head;
  head->succ = head;
  head->prec = head;
  head->list = list;
  
  return list;
}

void List_destroy(IntList *list) {
  IntListNode *node = (list->head)->succ,
    *next_node = node;
  while (node != list->head) {
    next_node = node->succ;
    free(node);
    node = next_node;
  }

  free(list->head);
  free(list);
  return;
}

IntListNode *ListNode_create(int value) {
  IntListNode *node = (IntListNode *)malloc(sizeof(IntListNode));
  if (!(node))
    return NULL;

  node->value = value;
  node->succ = node;
  node->prec = node;
  node->list = NULL;
  return node;
}

void ListNode_destroy(IntListNode *node) {
  if (!(node))
    return;

  if (node->list)
    --(node->list)->count;

  if (node->prec &&
      ((node->prec)->succ == node))
    (node->prec)->succ = node->succ;

  if (node->succ &&
      ((node->succ)->prec == node))
    (node->succ)->prec = node->prec;


  free(node);
  return;
}

IntList *List_push(IntListNode *node,IntList *list) {
  if (!(list))
    return NULL;

  ((list->head)->prec)->succ = node;
  node->prec = (list->head)->prec;
  (list->head)->prec = node;
  node->succ = list->head;
  ++(list->count);
  node->list = list;

  return list;
}

IntList *List_push_entry(IntList *list,int value) {
  if (!(list))
    return NULL;

  IntListNode *node = (IntListNode *) malloc(sizeof(IntListNode));
  if (!(node))
    return NULL;

  node->value = value;
  ((list->head)->prec)->succ = node;
  node->prec = (list->head)->prec;
  (list->head)->prec = node;
  node->succ = list->head;
  ++(list->count);
  node->list = list;

  return list;
}

IntList *List_pop(IntListNode *node) {
  if (!(node->list))
    return NULL;

  IntList *list = node->list;
  (node->prec)->succ = node->succ;
  (node->succ)->prec = node->prec;
  --(list->count);
  node->list = NULL;
  
  return list;

}

IntList *List_reinsert(IntListNode *node) {
  if (
      !(node->prec) ||  // need well-defined neighbors
      !(node->succ) ||
      !((node->succ)->list) || // should have a well-defined list
      !((node->prec)->list) || 
      (
       (node->prec != (node->succ)->prec) &&
       (node->succ != (node->prec)->succ))) // need neighbors to be connected
    return NULL;

  (node->prec)->succ = node;
  (node->succ)->prec = node;
  node->list = (node->succ)->list;
  ++(node->list)->count;
  return node->list;
}

IntListNode *List_access(IntList *list,int index) {
  if (!(list))
    return NULL;

  index = index % (list->count + 1);
  IntListNode *node = list->head;
  int node_index = 0;
  if (index <= (list->count + 1)/2) {
    while (node_index < index) {
      node = node->succ;
      ++node_index;
    }
    return node;
  }

  node_index = list->count +1;
  while (node_index > index) {
    node = node->prec;
    --node_index;
  }
  return node;

}

bool List_equal(IntList *list0, IntList *list1) {
  if (!(list0) ||
      !(list1))
    return false;

  if ( list0->count != list1->count )
    return false;

  IntListNode *node0 = (list0->head)->succ,
    *node1 = (list1->head)->succ;

  /*
   * @invariant node0 and node1 do not point to their respective pointers
   * @invariant node0 and node1 point to the element of index > i at iteration i
   * @invariant node0 and node1 have the same value if not head elements
   *
   */
  while ( (node0 != list0->head) &&
	  (node1 != list1->head) ) {
    if (node0->value != node1->value)
      return false;
    node0 = node0->succ;
    node1 = node1->succ;
  }

  // ensure that you have finished iterating
  return ( (node0 == list0->head) &&
	   (node1 == list1->head) );

}


void List_print(IntList *list) {
  if (!(list)) {
    printf("NULL list\n");
    return;
  }

  printf("List has %d nodes:\n",list->count);

  IntListNode *node = (list->head)->succ;
  int idx = 0;
  while (node != list->head) {
    if (idx)
      printf(", %d:%d",idx+1,node->value);
    else
      printf("%d:%d",idx+1,node->value);

    ++idx;
    node = node->succ;
  }
  printf("\n");
  return;
}
