/** @test_linked_list.h
 *  @brief Function prototypes to test linked_list on simple examples
 *
 *  This contains the prototypes for the linked
 *  list implementation test. This is an informal test
 *  that is meant to just demonstrate some functionality of the list
 *  
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>. 
 *  Copyright (C) 2015
 *
 *  @author Mark Stoehr ()
 *  @date 2015-02-02
 *  @bug No known bugs.
 */

#include "test_linked_list.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "linked_list.h"

bool test_List_create() {
  printf("Testing list creation facilities\n");
  IntList *list = List_create();
  printf("list is empty so it should have no nodes and zero count:\n");
  List_print(list);
  bool _count_is_zero_ = (bool) (list->count == 0);
  bool _head_is_by_itself_ = (bool) ( (list->head == (list->head)->succ ) &&
				      (list->head == (list->head)->prec));
  List_destroy(list); // cleanup
  return _count_is_zero_ && _head_is_by_itself_;
}

bool test_List_push() {
  printf("Testing the pushing utilities for lists starting with an empty list\n");
  IntList *list = List_create();
  List_print(list);
  int idx =0;
  printf("Pushing the values 0 through 9 to the empty list\n");
  bool _list_has_correct_number_of_nodes_ = (bool) (list->count == 0);
  for (; idx != 10; ++idx) {
    List_push_entry(list,idx);
    _list_has_correct_number_of_nodes_ = (bool) ( _list_has_correct_number_of_nodes_ &&
						  list->count == idx+1);
    List_print(list);
  }


  

  IntList *my_list = (IntList *)malloc(sizeof(IntList));
  // allocate 10 nodes
  IntListNode *nodes = (IntListNode *)malloc(11*sizeof(IntListNode));
  nodes->value = -1;
  nodes->list = my_list;
  nodes->prec = nodes+10;
  nodes->succ = nodes+1;
  my_list->head = nodes;

  for (idx=1;idx < 11; ++idx) {
    ++nodes;
    nodes->list = my_list;
    nodes->value = idx-1;
    (nodes-1)->succ = nodes;
    nodes->prec = nodes-1;
  }
  nodes->succ = my_list->head;
  my_list->count = 10;
  printf("\nHand-allocated identical list:\n");
  List_print(my_list);


  bool _hand_allocated_list_equals_pushed_list_ = List_equal(list,my_list);

  List_destroy(list); //cleanup
  free(my_list->head);
  free(my_list);
  return _list_has_correct_number_of_nodes_ && \
    _hand_allocated_list_equals_pushed_list_ ;
}

bool test_List_reinsert() {
  printf("\nTesting list reinsertion, Knuth's dancing links:\n");
  IntList *my_list0 = (IntList *)malloc(sizeof(IntList));
  // allocate 10 nodes
  IntListNode *nodes = (IntListNode *)malloc(5*sizeof(IntListNode));
  nodes->value = -1;
  nodes->list = my_list0;
  nodes->prec = nodes+4;
  nodes->succ = nodes+1;
  my_list0->head = nodes;
  int idx =1;
  for (;idx < 5; ++idx) {
    ++nodes;
    nodes->list = my_list0;
    nodes->value = idx;
    (nodes-1)->succ = nodes;
    nodes->prec = nodes-1;
  }
  nodes->succ = my_list0->head;
  my_list0->count = 4;


  IntList *my_list1 = (IntList *)malloc(sizeof(IntList));
  // allocate 10 nodes
  nodes = (IntListNode *)malloc(3*sizeof(IntListNode));
  nodes->value = -1;
  nodes->list = my_list1;
  nodes->prec = nodes+2;
  nodes->succ = nodes+1;
  my_list1->head = nodes;
  
  ++nodes;
  nodes->list = my_list1;
  nodes->value = 2;
  nodes->prec = nodes-1;
  nodes->succ = nodes+1;

  ++nodes;
  nodes->list = my_list1;
  nodes->value = 4;
  nodes->prec = nodes-1;
  nodes->succ = my_list1->head;
  my_list1->count = 2;

  IntList *list = List_create();
  
  for (idx=1; idx != 5; ++idx) 
    List_push_entry(list,idx);
  
  bool _pushed_list_equals_correct_hand_list_ = List_equal(list,my_list0);

  if (_pushed_list_equals_correct_hand_list_ )
    printf("Pushing works correctly\n");
  else
    printf("Pushing does not work correctly\n");

  IntListNode *node0 = (list->head)->succ,
    *node1 = List_access(list,3);

  List_pop(node0);
  List_pop(node1);

  _pushed_list_equals_correct_hand_list_ &= List_equal(list,my_list1);

  if (_pushed_list_equals_correct_hand_list_ )
    printf("Popping works correctly\n");
  else
    printf("Popping does not work correctly\n");


  List_reinsert(node0);
  List_reinsert(node1);



  _pushed_list_equals_correct_hand_list_ &= List_equal(list,my_list0);  

    
  return _pushed_list_equals_correct_hand_list_;
  

}

int main() {
  bool _test_List_create_outcome_ = test_List_create();
  if (_test_List_create_outcome_)
    printf("Creating lists:\tPASSED\n");
  else
    printf("Creating lists:\tFAILED\n");
  printf("\n\n");
  bool _test_List_push_outcome_ = test_List_push();
  if (_test_List_push_outcome_)
    printf("Pushing to lists:\tPASSED\n");
  else
    printf("Pushing to lists:\tFAILED\n");

  bool _test_List_reinsert_outcome_ = test_List_reinsert();
  if (_test_List_reinsert_outcome_)
    printf("Reinserting to lists:\tPASSED\n");
  else
    printf("Reinserting to lists:\tFAILED\n");

  printf("\n\n%d/%d tests passed.\n",_test_List_create_outcome_ +
	 _test_List_push_outcome_ +
	 _test_List_reinsert_outcome_,3);
  return 0;
}
