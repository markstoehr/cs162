/** @linked_list.h
 *  @brief Function prototypes for linked list implementations
 *
 *  This contains the prototypes for the linked
 *  list implementations.  It contains ints and 
 *  we have implemented efficient algorithms for insertion
 *  and deletion which is special to the data structure.
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>. 
 *  Copyright (C) 2015
 *
 *  @author Mark Stoehr ()
 *  @date 2015-02-02
 *  @bug No known bugs.
 */

#ifndef _CODE_PRETTY_LAB3_LINKED_LIST_H_
#define _CODE_PRETTY_LAB3_LINKED_LIST_H_

#include <stdbool.h>
#include <stdlib.h>

/*
 *  @brief A structure representing a doubly linked circularly
 *         linked (DLCL) list
 *
 *
 *
 *   @anchor IntListInvariants
 *
 *   The elements of the list are `struct IntListNode` which
 *   is given the `typedef` name `*IntListNode`.  These nodes store ints
 *
 *   @invariant `IntListNode->succ` and `IntListNode->prec` should always
 *             point to the lowest byte address of a live 
 *             `*IntListNode` allocated object.
 *
 *
 *   @invariant  If `node` of type `struct IntListNode` does not belong to
 *               any `struct IntList` object then `node->list == NULL`.
 *
 *
 *
 *
 *
 *   The list is a `struct IntList` object and the pointers to such
 *   objects are given the `typedef` name `IntList`.  
 *
 *   Int the following code let `list` be an allocated object of type
 *   `struct intList`. 
 *
 *   @invariant `list->head` always points to the lowest byte address
 *               of a live `struct IntListNode` allocated object. 
 *               Every list has a head element including the empty list
 *               this is also known as a sentinel node. It simplifies
 *               list operations.
 *
 *   @invariant (list->head)->list == list if `list` is an object of type
 *              `struct IntList`.
 *
 *   @invariant list->count is the number of `stuct IntListNode` accessible
 *              from `struct IntList` other than `list->head`
 *
 *   @invariant for any `node` of type `struct IntListNode` 'belonging'
 *              to the list we have `node->list == list`
 *      
 *   @invariant for any `node` of type `struct IntListNode` 'belonging'
 *              to `IntList list` there is a number `size_t index > 0` 
 *              associated with the node (but only implicitly).  
 *              This number is such that `0<= index <= list->count`
 *              If `index == 1` then `node == (list->head)->succ`
 *              If `index > 1` then `node == node_prec->succ`
 *              where the index of `node_prec` is `index-1`. The 
 *              index of `list->head` is `0`. For each index in
 *              `0 <= index <= list->count` there is exactly one
 *              `struct IntListNode` with that index.
 *
 *   @invariant for any `node` of type `struct IntListNode` belonging
 *              to `list` which is of type `struct IntList` 
 *              we may denote the index of `node` as `index`
 *              If `index == (list->head)->count` then 
 *              `node == (list->head)->prec` if 
 *               `index < (list->head)->count` then
 *              `node == succ_node->prec` where `succ_node` points to
 *               a `struct IntListNode` that belongs to `list` and has index
 *               `index+1`.
 *
 * 
 *
 *   The list is circular so the nodes are arrange in a ring with a handle
 *   each node points back to the original list. In the following assume we
 *
 *   struct IntList list;
 *   struct IntListNode node, head;
 *   
 *   all properly defined `head` is the head of `list` and `node` is some elemnt of
 *   `list`.
 *
 *   @invariant (node->prec)->succ == node
 *              (node->succ)->prec == node
 *               These conditions show that the 
 *               edge structure is locally linear
 *              which will always be true in a list. This invariant can be derived from above
 *
 *   @invariant (..((node->succ)->succ)->..)->succ == node iff the number of 
 *              ->succ operations is divisible by 
 *              `list->count + 1` where list == node->list
 *              and `node` belongs to `list`.  This is a consequence 
 *              of the ring structure
 *              This is a consequence of previously defined invariants. Essentially
 *              the same invariant holds where `succ` is replaced by `prec`.
 *
 *
 *  A `struct IntList` is said to be well-formed if it obeys all of these invariants.
 *
 */
struct IntListNode;
struct IntList;

typedef struct IntListNode {
  int value;
  struct IntList *list;      /**< handle in DLCL linked list */
  struct IntListNode *succ;  /**< successor in DLCL linked list */
  struct IntListNode *prec;  /**< predecessor in DLCL linked list */
} IntListNode;
  
typedef struct IntList {
  int count;
  IntListNode *head;
} IntList;


/* @brief Return a pointer to a newly allocated well-formed `struct IntList`
 *        see @ref IntListInvariants
 *           
 *
 * @post Returned pointer is either NULL or the byte address of the start
 *       of a newly allocated `struct IntList` obeying the structure
 *       invariants.  The list should be empty.
 *
 * @post From the invariants we can derive that the newly allocated 
 *       `struct IntList` should have a head node `struct IntListNode` defined
 *       and that head node should have its `succ` and `prec` fields point to itself
 *       since the list is empty.  The `count` field should be zero.
 */
IntList *List_create();

/* @brief  Destroy IntList objects through deallocation
 *
 * @param  struct IntList *list
 * @pre    `list` is a well-formed (see the @ref IntListInvariants) 
 *         `struct IntList`
 *
 * @post   `list` has been deallocated and all `struct IntListNode`
 *          objects belonging to `list` have been deallocated
 *
 *
 *
 *
 */
void List_destroy(IntList *);

/* @brief Create a list node with a specified value
 *
 * @param int value
 *        This contains the value to create
 *
 * @return  IntListNode *
 *
 * @invariant  If `node` of type `struct IntListNode` does not belong to
 *               any `struct IntList` object then `node->list == NULL`.
 *
 * @post  The returned pointer should be NULL
 *        or equal to the start address of a 
 *        newly allocated IntListNode
 *
 */
IntListNode *ListNode_create(int);

/* @brief Deallocate a list node object
 *
 * @param IntListNode *node
 *        a pointer to the object to be deallocated
 *
 * @post  The `IntListNode *` object should have the
 *        memory freed
 *
 * @post  The memory location with address `node` 
 *        is not equal to the successor or predecessor field
 *        of the potential `IntListNode` objects referred to
 *        by `node->prec` and `node->succ` prior to destruction
 *
 *        We can't guarantee that there aren't any dangling
 *        references to `node` after destruction.
 *
 * @post  The memory location pointed to by `node` 
 *        does not belong to any list
 *
 */
void ListNode_destroy(IntListNode *);


/* @brief Push a node onto the end of a list
 *
 * @param IntListNode *x
 *        Node to push onto the list
 *
 * @param IntList *list
 *        List to push `x` onto
 * 
 * @return IntList *list
 *         A NULL pointer if the push failed
 *         otherwise a `IntList *` pointing to
 *         a well-formed `IntList`
 *         object (see @ref IntListInvariants)
 *
 * @invariant  `list->count` should always be the number of nodes             
 *
 * @invariant  `node->list` should point to the list `node` belongs to             
 *
 * @post Do nothing or `list` has `x` added as the new
 *       predecessor to `list->head`, `list->count`
 *       is incremented, `x->list` now points to `list`
 *
 */
IntList *List_push(IntListNode *,IntList *);

/* @brief Push a node onto the end of a list with the specified value
 *
 * @param IntListNode *x
 *        Node to push onto the list
 *
 * @param IntList *list
 *        List to push `x` onto
 * 
 * @return IntList *list
 *         A NULL pointer if the push failed
 *         otherwise a `IntList *` pointing to
 *         a well-formed `IntList`
 *         object (see @ref IntListInvariants)
 *
 * @invariant  `list->count` should always be the number of nodes             
 *
 * @invariant  `node->list` should point to the list `node` belongs to             
 *
 * @post Do nothing or `list` has `x` added as the new
 *       predecessor to `list->head`, `list->count`
 *       is incremented, `x->list` now points to `list`
 *
 */
IntList *List_push_entry(IntList *,int);


/* @brief Pop a node from its parent list if there is one
 *        
 *        This method should just remove the link to the parent
 *        and it the neighbors of the node should change their link
 *        structure (prec and succ fields) to omit the node.
 *        The count should be decremented. The method should fail
 *        if it is not a part of a list or if the node is the head
 *        node of a list.
 *
 * @param IntListNode *x
 *        The node to pop
 *
 * @return IntList *list
 *         NULL if failed otherwise it returns the list of the popped node
 *
 * @invariant  If `node` of type `struct IntListNode` does not belong to
 *               any `struct IntList` object then `node->list == NULL`.
 *
 *
 * @invariant  `prec` and `succ` fields of the node should not change
 *             to make reinsertion easy 
 *
 * @invariant  `list->count` should always be the number of nodes             
 *
 * @invariant  `prec` and `succ` fields of the node should not change
 *             to make reinsertion easy 
 *
 *
 */
IntList *List_pop(IntListNode *);


/* @brief reinsert a node that has been popped back into the list
 *
 *        This is O(1) code for list reinsertion. We use knuth's dance
 *        If you can't reinsert (i.e. the predecessor and the successor
 *        are no longer adjacent in the original list) then you
 *        should return NULL otherwise you return a pointer to the list
 *        you just reinserted into
 *
 * @invariant  `list->count` should always be the number of nodes             
 *
 * @invariant   Any node belonging to a list should point to the list
 *
 *
 *
 *
 */
IntList *List_reinsert(IntListNode *);

/* @brief Access a list member by index
 *
 *        To make this general we wrap around the list
 *        so the node is taken by modolu count + 1
 *
 * @invariant list->count should always maintain the correct
 *            count for the nodes the list owns
 *
 *
 */
IntListNode *List_access(IntList *,int);

/* @brief Test whether two lists are equal
 * 
 *        Outputs 1 if they are equal otherwise outputs 0
 *        List are equal if they have the same data and topology.
 *        So we cycle through the nodes starting at the head
 *        and check the values
 *
 */
bool List_equal(IntList *,IntList *);

/* @brief Pretty print the contents of the list
 *
 *        Print the count and each element of the list
 *        prints in the form `(node index):(node value)`.
 *
 *
 *
 *
 *
 */
void List_print(IntList *);

/*
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 *
 *
 *
 *
 *
 *
 *
 *
 */

#endif // _CODE_PRETTY_LAB3_LINKED_LIST_H_
